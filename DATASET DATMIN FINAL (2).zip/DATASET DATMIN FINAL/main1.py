import pandas as pd

# Baca file dataset lama
df = pd.read_csv("dataset_sms_final.csv", encoding='utf-8')

# Cek kolom yang ada
print("Kolom yang ada di dataset:", df.columns.tolist())

# Pilih kolom 'teks' dan 'predicted_label' saja
df_baru = df[['teks', 'predicted_label']].copy()

# Ganti nama kolom 'predicted_label' jadi 'label' agar lebih standar (opsional)
df_baru.rename(columns={'predicted_label': 'label'}, inplace=True)

# Simpan ke CSV baru
df_baru.to_csv("dataset_sms_akhir.csv", index=False, encoding='utf-8')

print("✅ Dataset baru dengan hanya teks dan label sudah disimpan ke 'dataset_sms_akhir.csv'")
