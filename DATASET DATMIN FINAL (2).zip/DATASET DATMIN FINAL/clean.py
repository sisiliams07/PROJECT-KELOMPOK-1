import pandas as pd

# Baca file CSV dan lewati baris yang rusak
try:
    df = pd.read_csv("dataset_sms_final.csv", on_bad_lines='skip', encoding='utf-8')
except Exception as e:
    print("❌ Gagal membaca CSV:", e)
    exit()

# Hapus kolom 'label' jika ada
if 'label' in df.columns:
    df = df.drop(columns=['label'])
    print("✅ Kolom 'label' berhasil dihapus.")
else:
    print("⚠️ Kolom 'label' tidak ditemukan.")

# Ganti nama kolom 'message', 'sms', atau 'text' menjadi 'teks'
rename_candidates = ['message', 'pesan', 'text', 'sms', 'content']
for col in df.columns:
    if col.lower().strip() in rename_candidates:
        df.rename(columns={col: 'teks'}, inplace=True)
        print(f"✅ Kolom '{col}' berhasil diubah menjadi 'teks'.")
        break

# Simpan ke file baru
df.to_csv("dataset_sms_mentah_tanpa_label.csv", index=False)
print("✅ Dataset disimpan ke 'dataset_sms_mentah_tanpa_label.csv'")
