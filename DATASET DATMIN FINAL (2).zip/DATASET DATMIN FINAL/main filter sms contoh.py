import pandas as pd

# Baca file CSV dan lewati baris yang rusak
try:
    df = pd.read_csv("dataset_sms_mentah_tanpa_label.csv", on_bad_lines='skip', encoding='utf-8')
except Exception as e:
    print("❌ Gagal membaca CSV:", e)
    exit()

# Normalisasi nama kolom agar tidak case-sensitive
df.columns = [col.strip().lower() for col in df.columns]

# Hapus kolom 'number' dan 'date' jika ada
cols_to_drop = ['number', 'date']
existing_cols = [col for col in cols_to_drop if col in df.columns]

if existing_cols:
    df = df.drop(columns=existing_cols)
    print(f"✅ Kolom {existing_cols} berhasil dihapus.")
else:
    print("⚠️ Kolom 'number' atau 'date' tidak ditemukan.")

# Simpan ke file baru
df.to_csv("dataset_sms_bersih.csv", index=False)
print("✅ Dataset bersih disimpan ke 'dataset_sms_bersih.csv'")
