import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import NearestNeighbors
import csv

# === STEP 1: Load data dengan perlindungan error parsing ===
try:
    df_acuan = pd.read_csv("dataset_contoh.csv", encoding='utf-8')

    # Deteksi delimiter otomatis pada data mentah
    with open("dataset_sms_bersih.csv", encoding="utf-8") as f:
        header = f.readline()
        delimiter = ";" if ";" in header else ","

    df_mentah = pd.read_csv(
        "dataset_sms_bersih.csv",
        encoding="utf-8",
        quoting=csv.QUOTE_MINIMAL,
        on_bad_lines="skip",
        delimiter=delimiter
    )
except Exception as e:
    print("❌ Gagal membaca file CSV:", e)
    exit()

print("Jumlah data acuan:", len(df_acuan))
print("Jumlah data mentah awal:", len(df_mentah))

# === STEP 2: Rename kolom teks dan label jika perlu ===
rename_columns = {
    'sms': 'teks',
    'text': 'teks',
    'content': 'teks',
    'pesan': 'teks',
    'message': 'teks',
    'kategori': 'label',
    'type': 'label',
    'kelas': 'label'
}

df_acuan.rename(columns=lambda x: rename_columns.get(x.lower(), x), inplace=True)
df_mentah.rename(columns=lambda x: rename_columns.get(x.lower(), x), inplace=True)

# Validasi kolom wajib ada
if 'teks' not in df_acuan.columns or 'label' not in df_acuan.columns:
    print("❌ Kolom 'teks' atau 'label' tidak ditemukan dalam data acuan.")
    print("Kolom ditemukan di data acuan:", df_acuan.columns.tolist())
    exit()

if 'teks' not in df_mentah.columns:
    print("❌ Kolom 'teks' tidak ditemukan dalam data mentah.")
    print("Kolom ditemukan di data mentah:", df_mentah.columns.tolist())
    exit()

# === STEP 3: Bersihkan NaN dan teks kosong/spasi ===
print("Data acuan sebelum drop NaN:", len(df_acuan))
df_acuan = df_acuan.dropna(subset=['teks', 'label'])
print("Data acuan setelah drop NaN:", len(df_acuan))

print("Data mentah sebelum drop NaN:", len(df_mentah))
df_mentah = df_mentah.dropna(subset=['teks'])
print("Data mentah setelah drop NaN:", len(df_mentah))

# Hapus baris dengan teks kosong atau hanya spasi
df_mentah = df_mentah[df_mentah['teks'].astype(str).str.strip() != '']
print("Data mentah setelah hapus teks kosong/spasi:", len(df_mentah))

# Bersihkan teks dari spasi ekstra
df_acuan['teks'] = df_acuan['teks'].astype(str).str.strip()
df_mentah['teks'] = df_mentah['teks'].astype(str).str.strip()

# === STEP 4: Gabungkan teks untuk fit TF-IDF ===
all_text = pd.concat([df_acuan['teks'], df_mentah['teks']], ignore_index=True)

vectorizer = TfidfVectorizer()
tfidf_all = vectorizer.fit_transform(all_text)

tfidf_acuan = tfidf_all[:len(df_acuan)]
tfidf_mentah = tfidf_all[len(df_acuan):]

# === STEP 5: Nearest Neighbors ===
nn = NearestNeighbors(n_neighbors=1, metric='cosine')
nn.fit(tfidf_acuan)

distances, indices = nn.kneighbors(tfidf_mentah)

predicted_labels = df_acuan.iloc[indices.flatten()]['label'].values
df_mentah['predicted_label'] = predicted_labels

# === STEP 6: Simpan hasil ===
print("Jumlah data akhir:", len(df_mentah))
print("Distribusi label hasil prediksi:\n", df_mentah['predicted_label'].value_counts())

df_mentah.to_csv("dataset_sms_final.csv", index=False)
print("✅ Semua data berhasil diproses dan disimpan ke 'dataset_sms_final.csv'")
